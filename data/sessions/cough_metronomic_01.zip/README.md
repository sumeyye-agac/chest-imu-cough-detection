# Movesense recording - "cough_metronomic"

Captured 2026-09-16 13:15:30 (local time), 2 min 3 s long, from a Movesense sensor.

## Read this first

- IMU9 was subscribed at 208 Hz but the sensor delivered 216.216 Hz. Sample spacing follows the measured rate; meta.json records both.

## What is in here

| file | rows | contents |
|---|---|---|
| `ecg.csv` | 15,456 | single-lead ECG in millivolts, one row per sample, 125 Hz requested / 125.0 Hz delivered |
| `imu.csv` | 26,600 | accelerometer (m/s²), gyroscope (°/s) and magnetometer (µT), three axes each, 208 Hz requested / 216.216 Hz delivered |
| `hr.csv` | 191 | heart rate in bpm plus a rolling unfiltered SDNN, about one row per second |
| `rr.csv` | 191 | inter-beat (RR) intervals in ms, one row per beat |
| `temp.csv` | 23 | skin-side temperature in °C - the sensor only reports it when it changes |
| `meta.json` | - | the same facts as this file, machine-readable |

## The time columns

Every CSV starts with the same four columns, so one loader reads them all.

| column | meaning |
|---|---|
| `t_s` | seconds since the recording started - the axis to plot against |
| `t_device_ms` | the sensor's own clock, in ms, with uint32 wraps undone |
| `t_unix` | absolute time, derived from the device clock - **use this for analysis** |
| `t_recv_unix` | when the Bluetooth packet reached the computer - diagnostic only |

Two clocks are involved and neither alone is sufficient. The sensor's clock
spaces samples accurately but counts from its own power-on; the computer's
clock is absolute but is only stamped when a packet arrives, and Bluetooth
delivers ECG and IMU9 in batches of many samples at once. `t_unix` combines
them: the sensor's spacing, anchored to the computer's clock once at the
start. Each stream (ECG, IMU9, temp) anchors itself independently - they
report their own Timestamp field and are not the same counter, so mixing
them up would misdate one stream by that offset. `t_recv_unix` is kept so
the gap between the two - the Bluetooth delivery latency - stays visible
instead of being baked invisibly into the timeline. Samples from one packet
share a `t_recv_unix`; that is expected.

## Loading it

```python
import pandas as pd

ecg = pd.read_csv("ecg.csv")
ecg["t_unix"].diff().describe()   # sample spacing, should be near-constant
```

## Things to know before trusting it

- **Sample spacing follows what the sensor actually delivered**, not what was
  asked for. The two can differ - IMU9 subscribed at 52 Hz tends to deliver
  about 54 - so `meta.json` records `rate_hz` and `measured_rate_hz`
  separately for each stream.
- **The first row's `t_s` can be a few milliseconds negative.** Each stream
  anchors its own device clock at its own first packet; a packet may carry
  an earlier timestamp because it was sampled just before recording began
  and only delivered just after.
- **Magnetometer values are raw and uncalibrated.** They carry a hard-iron
  offset, so their magnitude is not Earth's field strength. Calibrate by
  rotating the sensor through many orientations and fitting a sphere.
- **`rr.csv` holds inter-beat intervals in delivery order, not beat times.**
  Absolute beat times are deliberately not reconstructed here: one dropped
  notification would make a cumulative sum silently wrong.
- **`hr.csv` and `rr.csv` have an empty `t_device_ms`.** They come over the
  standard Bluetooth Heart Rate Service, which carries no device timestamp
  at all, so `t_unix` there can only be arrival time.
- **`sdnn_ms` is unfiltered** - the standard deviation of raw RR intervals
  over a rolling window, with no ectopic-beat correction. For real HRV work,
  compute it yourself from `rr.csv`.

Written by the Movesense Live Dashboard.
